import { NextResponse } from "next/server";

export const dynamic = "force-static";

// Returns the public VAPID key so the browser can subscribe to push notifications.
export async function GET() {
  const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  if (!publicKey) {
    return NextResponse.json({ error: "Push not configured" }, { status: 503 });
  }
  return NextResponse.json({ publicKey });
}
